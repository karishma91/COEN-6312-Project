package RealEstateSystem2;

public class Buyer extends User {

	/**
	 * 
	 */
	public void Buy_Prop() { 
		// TODO Auto-generated method
	 } 

}
