package RealEstateSystem2;

public class Sell_Property extends Transaction_Type { 

}
