package RealEstateSystem2;

public class Residential extends Property { 

}
