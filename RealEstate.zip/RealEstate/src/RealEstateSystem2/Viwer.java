package RealEstateSystem2;

public class Viwer extends User {

	/**
	 * 
	 */
	public void View_Prop() { 
		// TODO Auto-generated method
	 } 

}
