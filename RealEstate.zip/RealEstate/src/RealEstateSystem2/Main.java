package RealEstateSystem2;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    static ArrayList<User> user;
    static ArrayList<Property> prop;
    static String choice;
    
    public static void main(String[] args) {
        user = new ArrayList();
        Scanner scanner = new Scanner(System.in);
        choice = "";
        boolean isAuthenticUser = false;
        while (!choice.equals("6")) {
//            isAuthenticUser = false;
            System.out.println("Please enter your choice:");
            System.out.println("1: Register User");
            System.out.println("2: User Login");
            System.out.println("3: List Property");
            System.out.println("4: Buy Property");
            System.out.println("5: Enquiry");
            System.out.println("6: Exit");
            choice = scanner.nextLine();
            switch (choice) {
                case "1":
                    System.out.println();
                    System.out.println("Your choice - 1: Register User");
                    registerUser();
                    System.out.println();
                    break;
                case "2":
                    System.out.println();
                    System.out.println("Your choice - 2: User Login");
                    isAuthenticUser = userLogin();
                    System.out.println();
                    break;
                case "3":
                    System.out.println();
                    System.out.println("Your choice - 3: List Property (User Login Required)");
//                    isAuthenticUser = userLogin();
                    if (isAuthenticUser) {
                        listProperty();
                    }
                    System.out.println();
                    break;
                case "4":
                    System.out.println();
                    System.out.println("Your choice - 4: Buy Property (User Login Required)");
//                    isAuthenticUser = userLogin();
                    if (isAuthenticUser) {
                        
                    }
                    System.out.println();
                    break;
                case "5":
                    System.out.println();
                    System.out.println("Your choice - 5: Enquiry (User Login Required)");
//                    isAuthenticUser = userLogin();
                    if (isAuthenticUser) {
                        
                    }
                    System.out.println();
                    break;
                case "6":
                    System.out.println();
                    System.out.println("Your choice - 6: Exit");
                    System.out.println();
                    System.out.println("Exiting!");
                    break;
                default:
                    System.out.println();
                    System.out.println("Try Again!");
                    
                    System.out.println();
                    break;
            }
        }
    }

    public static void registerUser() {
        User u = new User();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter username:");
        u.setUser_Name(scanner.nextLine());
        System.out.println("Please enter password:");
        u.setPassword(scanner.nextLine());
//        System.out.println("Please enter username:");
//        u1.setUser_Name(scanner.nextLine());
//        System.out.println("Please enter username:");
//        u1.setUser_Name(scanner.nextLine());
//        System.out.println("Please enter username:");
//        u1.setUser_Name(scanner.nextLine());
        user.add(u);
    }

    private static boolean userLogin() {
        User u;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter username:");
        String uname = scanner.nextLine();
        System.out.println("Please enter password:");
        String pass = scanner.nextLine();
        boolean validity = false;
        for (int i = 0; i < user.size(); i++) {
            u = user.get(i);
            if ( u.getUser_Name().equals(uname) && u.getPassword().equals(pass) ) {
                System.out.println("User login successful!");
                validity = true;
                break;
            }
//            validity = false;
        }
        if(!validity)
        {
            System.out.println("Incorrect username or password!");
        }
        return validity;
    }

    private static void listProperty() {
        Property p;
        System.out.println("1: Concordia SGW");
        System.out.println("2: Concordia Loyola");
        System.out.println("3: Concordia GN");
        System.out.println("4: Concordia FG");
        System.out.println("5: Concordia CE");
        System.out.println("6: Moose Bar");
    }
}
