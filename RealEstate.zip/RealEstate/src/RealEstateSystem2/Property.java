package RealEstateSystem2;

import java.util.List;

public class Property {

	/**
	 * 
	 */
	private String Property_Type;
	/**
	 * 
	 */
	private String Location;
	/**
	 * 
	 */
	private String Status;
	/**
	 * 
	 */
	private Integer Price;
	/**
	 * 
	 */
	private Integer Area;
	/**
	 * 
	 */
	public List<Real_Estate_System> contains;
	/**
	 * 
	 */
	public List<Transaction_Type> transaction_Type;
	/**
	 * Getter of Property_Type
	 */
	public String getProperty_Type() {
	 	 return Property_Type; 
	}
	/**
	 * Setter of Property_Type
	 */
	public void setProperty_Type(String Property_Type) { 
		 this.Property_Type = Property_Type; 
	}
	/**
	 * Getter of Location
	 */
	public String getLocation() {
	 	 return Location; 
	}
	/**
	 * Setter of Location
	 */
	public void setLocation(String Location) { 
		 this.Location = Location; 
	}
	/**
	 * Getter of Status
	 */
	public String getStatus() {
	 	 return Status; 
	}
	/**
	 * Setter of Status
	 */
	public void setStatus(String Status) { 
		 this.Status = Status; 
	}
	/**
	 * Getter of Price
	 */
	public Integer getPrice() {
	 	 return Price; 
	}
	/**
	 * Setter of Price
	 */
	public void setPrice(Integer Price) { 
		 this.Price = Price; 
	}
	/**
	 * Getter of Area
	 */
	public Integer getArea() {
	 	 return Area; 
	}
	/**
	 * Setter of Area
	 */
	public void setArea(Integer Area) { 
		 this.Area = Area; 
	}
	/**
	 * Getter of contains
	 */
	public List<Real_Estate_System> getContains() {
	 	 return contains; 
	}
	/**
	 * Setter of contains
	 */
	public void setContains(List<Real_Estate_System> contains) { 
		 this.contains = contains; 
	}
	/**
	 * Getter of transaction_Type
	 */
	public List<Transaction_Type> getTransaction_Type() {
	 	 return transaction_Type; 
	}
	/**
	 * Setter of transaction_Type
	 */
	public void setTransaction_Type(List<Transaction_Type> transaction_Type) { 
		 this.transaction_Type = transaction_Type; 
	} 

}
