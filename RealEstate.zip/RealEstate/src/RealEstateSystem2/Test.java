package RealEstateSystem2;

public class Test {
    public static void main2(String[] args) {
        
        
        
//    String[] user = new String[10];
//    System.out.println(user.length);
//    int i=0;
//    while(user[i]!=null)
//    {
//        i++;
////        System.out.println(user[i]);
//    }
//    System.out.println("i="+i);
//    user[i] = "HeHe";
//    
//    while(user[i]!=null)
//    {
//        i++;
////        System.out.println(user[i]);
//    }
//    System.out.println("i="+i);
//    user[i] = "HeHe";
//    
//    for (int j = 0; j < user.length; j++) {
//        System.out.println(user[j]);
//    }
    }
}
