package RealEstateSystem2;

public class View_Property extends Transaction_Type { 

}
