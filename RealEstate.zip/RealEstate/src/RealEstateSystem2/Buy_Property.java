package RealEstateSystem2;

public class Buy_Property extends Transaction_Type { 

}
