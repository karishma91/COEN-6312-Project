package RealEstateSystem2;

public class Comercial extends Property { 

}
