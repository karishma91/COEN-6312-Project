package RealEstateSystem2;

import java.util.List;

public class Administrator extends User {

	/**
	 * 
	 */
	public String Admin_Name;
	/**
	 * 
	 */
	public Real_Estate_System partof;
	/**
	 * 
	 */
	public List<Property> Approves;
	/**
	 * 
	 */
	public Account Manages;
	/**
	 * Getter of Admin_Name
	 */
	public String getAdmin_Name() {
	 	 return Admin_Name; 
	}
	/**
	 * Setter of Admin_Name
	 */
	public void setAdmin_Name(String Admin_Name) { 
		 this.Admin_Name = Admin_Name; 
	}
	/**
	 * Getter of partof
	 */
	public Real_Estate_System getPartof() {
	 	 return partof; 
	}
	/**
	 * Setter of partof
	 */
	public void setPartof(Real_Estate_System partof) { 
		 this.partof = partof; 
	}
	/**
	 * Getter of Approves
	 */
	public List<Property> getApproves() {
	 	 return Approves; 
	}
	/**
	 * Setter of Approves
	 */
	public void setApproves(List<Property> Approves) { 
		 this.Approves = Approves; 
	}
	/**
	 * 
	 */
	public void List_User() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void Add_User() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void Delete_User() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void Delete_Prop() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void Add_Prop() { 
		// TODO Auto-generated method
	 }
	/**
	 * Getter of Manages
	 */
	public Account getManages() {
	 	 return Manages; 
	}
	/**
	 * Setter of Manages
	 */
	public void setManages(Account Manages) { 
		 this.Manages = Manages; 
	} 

}
