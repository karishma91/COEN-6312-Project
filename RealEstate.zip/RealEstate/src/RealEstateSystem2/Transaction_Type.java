package RealEstateSystem2;

public class Transaction_Type {

	/**
	 * 
	 */
	public String Prop_Type;

	/**
	 * Getter of Prop_Type
	 */
	public String getProp_Type() {
	 	 return Prop_Type; 
	}

	/**
	 * Setter of Prop_Type
	 */
	public void setProp_Type(String Prop_Type) { 
		 this.Prop_Type = Prop_Type; 
	} 

}
