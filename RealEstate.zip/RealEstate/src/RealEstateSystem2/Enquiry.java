package RealEstateSystem2;

public class Enquiry {

	/**
	 * 
	 */
	public Integer Message_Id;
	/**
	 * 
	 */
	public String Message_detail;
	/**
	 * Getter of Message_Id
	 */
	public Integer getMessage_Id() {
	 	 return Message_Id; 
	}
	/**
	 * Setter of Message_Id
	 */
	public void setMessage_Id(Integer Message_Id) { 
		 this.Message_Id = Message_Id; 
	}
	/**
	 * Getter of Message_detail
	 */
	public String getMessage_detail() {
	 	 return Message_detail; 
	}
	/**
	 * Setter of Message_detail
	 */
	public void setMessage_detail(String Message_detail) { 
		 this.Message_detail = Message_detail; 
	}
	/**
	 * 
	 */
	public void Receive_Message() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void Send_Message() { 
		// TODO Auto-generated method
	 } 

}
