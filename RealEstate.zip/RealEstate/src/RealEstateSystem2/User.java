package RealEstateSystem2;

public class User {

	/**
	 * 
	 */
	public String User_Name;
	/**
	 * 
	 */
	public String Password;
	/**
	 * 
	 */
	public Integer User_Age;
	/**
	 * 
	 */
	public Integer User_Id;
	/**
	 * 
	 */
	public String Login_Status;
	/**
	 * 
	 */
	public Enquiry Generates;
	/**
	 * 
	 */
	public Property Access;
	/**
	 * Getter of User_Name
	 */
	public String getUser_Name() {
	 	 return this.User_Name; 
	}
	/**
	 * Setter of User_Name
	 */
	public void setUser_Name(String User_Name) { 
		 this.User_Name = User_Name; 
	}
	/**
	 * Getter of Password
	 */
	public String getPassword() {
	 	 return this.Password; 
	}
	/**
	 * Setter of Password
	 */
	public void setPassword(String Password) { 
		 this.Password = Password; 
	}
	/**
	 * Getter of User_Age
	 */
	public Integer getUser_Age() {
	 	 return this.User_Age; 
	}
	/**
	 * Setter of User_Age
	 */
	public void setUser_Age(Integer User_Age) { 
		 this.User_Age = User_Age; 
	}
	/**
	 * Getter of User_Id
	 */
	public Integer getUser_Id() {
	 	 return this.User_Id; 
	}
	/**
	 * Setter of User_Id
	 */
	public void setUser_Id(Integer User_Id) { 
		 this.User_Id = User_Id; 
	}
	/**
	 * Getter of Login_Status
	 */
	public String getLogin_Status() {
	 	 return this.Login_Status; 
	}
	/**
	 * Setter of Login_Status
	 */
	public void setLogin_Status(String Login_Status) { 
		 this.Login_Status = Login_Status; 
	}
	/**
	 * Getter of Generates
	 */
	public Enquiry getGenerates() {
	 	 return this.Generates; 
	}
	/**
	 * Setter of Generates
	 */
	public void setGenerates(Enquiry Generates) { 
		 this.Generates = Generates; 
	}
	/**
	 * 
	 * @param User_Name 
	 * @param Password 
	 */
	public void Verify_Login(String User_Name, String Password) { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void Logout() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void Forgot_Pass() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void Register_Account() { 
		// TODO Auto-generated method
	 }
	/**
	 * Getter of Access
	 */
	public Property getAccess() {
	 	 return this.Access; 
	}
	/**
	 * Setter of Access
	 */
	public void setAccess(Property Access) { 
		 this.Access = Access; 
	} 

}
