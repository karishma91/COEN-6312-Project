package RealEstateSystem2;

public class Account {

	/**
	 * 
	 */
	public String Name;
	/**
	 * 
	 */
	public String Address;
	/**
	 * 
	 */
	public Integer Phone_No;
	/**
	 * 
	 */
	public String Email_Id;
	/**
	 * 
	 */
	public Integer DOB;
	/**
	 * 
	 */
	public User CreatedBy;
	/**
	 * Getter of Name
	 */
	public String getName() {
	 	 return Name; 
	}
	/**
	 * Setter of Name
	 */
	public void setName(String Name) { 
		 this.Name = Name; 
	}
	/**
	 * Getter of Address
	 */
	public String getAddress() {
	 	 return Address; 
	}
	/**
	 * Setter of Address
	 */
	public void setAddress(String Address) { 
		 this.Address = Address; 
	}
	/**
	 * Getter of Phone_No
	 */
	public Integer getPhone_No() {
	 	 return Phone_No; 
	}
	/**
	 * Setter of Phone_No
	 */
	public void setPhone_No(Integer Phone_No) { 
		 this.Phone_No = Phone_No; 
	}
	/**
	 * Getter of Email_Id
	 */
	public String getEmail_Id() {
	 	 return Email_Id; 
	}
	/**
	 * Setter of Email_Id
	 */
	public void setEmail_Id(String Email_Id) { 
		 this.Email_Id = Email_Id; 
	}
	/**
	 * Getter of DOB
	 */
	public Integer getDOB() {
	 	 return DOB; 
	}
	/**
	 * Setter of DOB
	 */
	public void setDOB(Integer DOB) { 
		 this.DOB = DOB; 
	}
	/**
	 * Getter of CreatedBy
	 */
	public User getCreatedBy() {
	 	 return CreatedBy; 
	}
	/**
	 * Setter of CreatedBy
	 */
	public void setCreatedBy(User CreatedBy) { 
		 this.CreatedBy = CreatedBy; 
	}
	/**
	 * 
	 */
	public void Update_Acc() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void Delete_Acc() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void Add_Acc() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void Change_Pass() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void Update_Profile() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void Delete_Profile() { 
		// TODO Auto-generated method
	 }
	/**
	 * 
	 */
	public void Register_Acc() { 
		// TODO Auto-generated method
	 } 

}
