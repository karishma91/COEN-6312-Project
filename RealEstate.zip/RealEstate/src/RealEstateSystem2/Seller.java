package RealEstateSystem2;

public class Seller extends User {

	/**
	 * 
	 */
	private Integer Seller_Id;

	/**
	 * Getter of Seller_Id
	 */
	public Integer getSeller_Id() {
	 	 return Seller_Id; 
	}

	/**
	 * Setter of Seller_Id
	 */
	public void setSeller_Id(Integer Seller_Id) { 
		 this.Seller_Id = Seller_Id; 
	}

	/**
	 * 
	 */
	public void Sell_Prop() { 
		// TODO Auto-generated method
	 } 

}
