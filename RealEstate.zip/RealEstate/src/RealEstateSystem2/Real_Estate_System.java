package RealEstateSystem2;

import java.util.List;

public class Real_Estate_System {

	/**
	 * 
	 */
	public List<User> holds;

	/**
	 * Getter of holds
	 */
	public List<User> getHolds() {
	 	 return holds; 
	}

	/**
	 * Setter of holds
	 */
	public void setHolds(List<User> holds) { 
		 this.holds = holds; 
	} 

}
